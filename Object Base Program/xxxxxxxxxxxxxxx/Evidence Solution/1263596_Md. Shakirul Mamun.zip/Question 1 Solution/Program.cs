﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_1_Solution
{
    class Program
    {
        static void Main(string[] args)
        {
            #region       // if....else loop.......//Compare two value which is big or small
            int i = 10;
            int j = 20;
            if (i > j)
            {
                Console.WriteLine("i biger than j");
            }
            else
            {
                Console.WriteLine("i less than j");
            }
            Console.ReadKey();
            #endregion

            #region       // Switch case........//Find out Month Name
           
            int month = 1;
            switch (month)
            {
                case 1:
                    Console.WriteLine("Jan");
                    break;
                case 2:
                    Console.WriteLine("Feb");
                    break;
                case 3:
                    Console.WriteLine("Mar");
                    break;
                case 4:
                    Console.WriteLine("April");
                    break;
                case 5:
                    Console.WriteLine("May");
                    break;
                case 6:
                    Console.WriteLine("Jun");
                    break;
                case 7:
                    Console.WriteLine("Jul");
                    break;
                case 8:
                    Console.WriteLine("Aug");
                    break;
                case 9:
                    Console.WriteLine("Sep");
                    break;
                case 10:
                    Console.WriteLine("Oct");
                    break;
                case 11:
                    Console.WriteLine("Nov");
                    break;
                case 12:
                    Console.WriteLine("Dec");
                    break;
                default:
                    Console.WriteLine("!opps");
                    break;
            }
            Console.ReadKey();
            #endregion

            #region      // while ...loop       //find out even value in (0-50)
            int m = 0;
            while (m <= 50)
            {
                Console.WriteLine(m);
                m=m+2;
            }
            Console.ReadKey();
            #endregion

            #region    //For....Loop      // Compare value than find out result

            for (int n = 0; n < 100; n = n + 10)
            {
                if (n > 80 && n < 100)
                {
                    Console.WriteLine("Your result is pass");
                }
                else
                {
                    Console.WriteLine("Your result is fail");
                }
            }
            Console.ReadKey();

            #endregion

            #region     // do....while loop      //find out odd number in (1-15)
            int a = 1;
            do
            {
                
                Console.WriteLine(a);
                a = a + 2;
                Console.ReadKey();
            }
            while (a <= 15);
            #endregion

            #region   //foreach...loop   //find out array list
            string[] books = { "Math", "Bangla", "English", "PHP" };
            foreach (string book in books)
            {
                Console.WriteLine(book);
            }
            Console.ReadKey();
            #endregion



        }



    }

    
}
