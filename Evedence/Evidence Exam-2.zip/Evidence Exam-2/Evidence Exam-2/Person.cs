﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evidence_Exam_2
{
    public abstract class Person

    {
        public string Name { get; set; }
        public DateTime DoB { get; set; }
    }
}
