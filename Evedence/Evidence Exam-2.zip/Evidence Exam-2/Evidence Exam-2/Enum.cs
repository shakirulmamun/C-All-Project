﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evidence_Exam_2
{
    public enum Designations

    {

        Programmer = 1, 
        Manager = 2, 
        CTO = 3,
        PD=4

    }
}
