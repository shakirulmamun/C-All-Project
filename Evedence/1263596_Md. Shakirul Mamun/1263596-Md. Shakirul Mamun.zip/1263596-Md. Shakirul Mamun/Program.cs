﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice_Part
{
    class Program
    {
        static void Main(string[] args)
        {
            //----------------------------if....Else Condition----------------------------
            //int month;

            //Console.Write("Input Month Duration : ");
            //month = Convert.ToInt32(Console.ReadLine());

            //if (month == 30)
            //{
            //    Console.WriteLine("April,June, August, November");

            //}
            //else if (month == 29)
            //{
            //    Console.WriteLine("Jan,Feb,Mar,May,Jul");
            //}
            //else
            //{
            //    Console.WriteLine("Invalid Number");
            //}
            //----------------------------if....Else Condition----------------------------
            //int number = 12;

            //if (number < 5)
            //{
            //    Console.WriteLine("{0} is less than 5", number);
            //}
            //else if (number > 5)
            //{
            //    Console.WriteLine("{0} is greater than 5", number);
            //}
            //else
            //{
            //    Console.WriteLine("{0} is equal to 5");
            //}
            //----------------------------if....Else Condition----------------------------
            //int i = 10;
            //int j = 20;

            //if (i == j)
            //{
            //    Console.WriteLine("i is equal to j");
            //}
            //else if (i > j)
            //{
            //    Console.WriteLine("i is greater than j");
            //}
            //else if (i < j)
            //{
            //    Console.WriteLine("i is less than j");
            //}
            //-----------------------switch Case------------------------

            //int day = 5;

            //switch (day)
            //{
            //    case 1:
            //        Console.WriteLine("Sutarday");
            //        break;

            //    case 2:
            //        Console.WriteLine("Sunday");
            //        break;
            //    case 3:
            //        Console.WriteLine("Monday");
            //        break;

            //    default:
            //        Console.WriteLine("opps!");
            //        break;
            //-----------------------switch Case------------------------
            //int x = 155;
            //switch (x % 2)
            //{
            //    case 1:
            //        Console.WriteLine($"{ x} is the Even value");
            //        break;
            //    case 2:
            //        Console.WriteLine($"{ x} is the Odd value");
            //        break;

            //}
            //-----------------------switch Case------------------------
            //int month;

            //Console.Write("\n\n");
            //Console.Write("Read month number and display month name:\n");
            //Console.Write("-------------------------------------------");
            //Console.Write("\n\n");


            //Console.Write("Input Month No : ");
            //month = Convert.ToInt32(Console.ReadLine());

            //switch (month)
            //{
            //    case 1:
            //        Console.Write("January\n");
            //        break;
            //    case 2:
            //        Console.Write("February\n");
            //        break;
            //    case 3:
            //        Console.Write("March\n");
            //        break;
            //    case 4:
            //        Console.Write("April\n");
            //        break;
            //    case 5:
            //        Console.Write("May\n");
            //        break;
            //    case 6:
            //        Console.Write("June\n");
            //        break;
            //    case 7:
            //        Console.Write("July\n");
            //        break;
            //    case 8:
            //        Console.Write("August\n");
            //        break;
            //    case 9:
            //        Console.Write("September\n");
            //        break;
            //    case 10:
            //        Console.Write("October\n");
            //        break;
            //    case 11:
            //        Console.Write("November\n");
            //        break;
            //    case 12:
            //        Console.Write("December\n");
            //        break;
            //    default:
            //        Console.Write("invalid Month number.");

            //        break;

        }

            //Console.ReadKey();

    }

      


        

  
}
