﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evidence
{
    class Program
    {
        static void Main(string[] args)
        {
            //-----------------If Else--------------
             Console.WriteLine("\n\t\t------------Leap Year Test-------");
             Console.Write("\nEnter your value: ");
             int day = Convert.ToInt32(Console.ReadLine());
             if (day == 29)
             {
                 Console.WriteLine("\nThis is Leap Year");
             }
             else if (day == 28)
             {
                 Console.WriteLine("This is Not Leap Year");
             }
             else
             {
                 Console.WriteLine("Wrong Input");
             }
            
            //-----------------Switch--------------

             Console.WriteLine("\n\t\t -------------Grading System Using Switch---------");
             int Mark;
             Console.Write("\nEnter Your Mark: ");
             Mark = Convert.ToInt32(Console.ReadLine());
             switch (Mark / 10)
             {
                 case 10:
                 case 9:
                 case 8:
                     Console.WriteLine("Your Grade Is : A+");
                     break;
                 case 7:
                     Console.WriteLine("your Grade is : A");
                     break;
                 case 6:
                     Console.WriteLine("your Grade is : A-");
                     break;
                 case 5:
                     Console.WriteLine("your Grade is : B");
                     break;
                 case 4:
                     Console.WriteLine("your Grade is : C");
                     break;
                 case 3:
                 case 2:
                 case 1:
                     Console.WriteLine("Your Grade Is : F");
                     break;
                 default:
                     Console.WriteLine("Invalid Marks");
                     break;

             }
            Console.ReadLine();
            
            //--------------------While Loop-----------
            Console.WriteLine("\n\n\t--------------Odd Number Using While Loop---------");
            int i = 1;
            while (i <= 10)
            {

                Console.WriteLine(i);
                i=i+2;
            }
            Console.ReadLine();
            //---------------For Loop----------
            Console.WriteLine("\t\t-----------Series Sum Using For Loop----");
            int j,sum=0;
            for(j=1;j<=100;j++)
            {
                sum = sum + j;
            }
            Console.WriteLine("\n1 to 100 Summation= " + sum);
            Console.ReadLine();
            //-----------Do while-------------
            Console.WriteLine("\n\t\t-------------Even Number Using Do While Loop---------");
            int E=2;
            do
            {
                Console.WriteLine(E);
                E = E + 2;
            }
            while (E <= 20);
            Console.ReadLine();
            //---------------Foreach----------------

            Console.WriteLine("\t\t-------------Foreach Loop-----------");
            string[] myfriends = { "Jahid", "Kasem", "Mejbah", "Tusar" };

            foreach (string Friends in myfriends)
            {
                Console.WriteLine(Friends);
            }
            Console.ReadLine();
            //---------------Declaring, Naming and Assigning Variable----------------
            Console.WriteLine("\t---------Arithmetic Operators--------");
            int num1 = 13, num2=21, num3=15;
            int sub, Div, Mul, Modulus;
            double avg;
            double summation = num1 + num2+ num3;
            sub = num2 - num3;
            Div = num2 / num3;
            Mul = num1 * num3;
            Modulus = num2 % num3;
            avg = summation / 3;
            Console.WriteLine("\nSummation: " + summation);
            Console.WriteLine("\nSubstration: " + sub);
            Console.WriteLine("\nDivision: " + Div);
            Console.WriteLine("\nMultiple: " + Mul);
            Console.WriteLine("\nModulus: " + Modulus);
            Console.WriteLine("\nAverage: " + avg);
            Console.ReadLine();
            //----------------Prefix and Postfix---------------
            Console.WriteLine("\n\t\t---------Prefix and Postfix-------");
            int pre = 1;
            ++pre;
            Console.WriteLine("Prefix: " + pre);
            int pos = 0;
            pos++;
            Console.WriteLine("Prefix: " + pos);
            //---------------Method----------





        }
    }
}
