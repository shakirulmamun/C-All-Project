﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductLINQ
{
    class Program
    {
        static void Main(string[] arg)
        {
            var products = new Product[]
           {
                new Product{ProductNumber=1, Name="HL Mountain Frame", ListPrice=200.30, Weight=1251.91, CategoryID=1, ProductModelID=1 },
                new Product{ProductNumber=2, Name="HL Mountain Frame", ListPrice=200.30, Weight=1251.91, CategoryID=2, ProductModelID=2 },
                new Product{ProductNumber=3, Name="HL Mountain Frame", ListPrice=200.30, Weight=1251.91, CategoryID=3, ProductModelID=3 },
                new Product{ProductNumber=1, Name="HL Mountain Frame", ListPrice=200.30, Weight=1251.91, CategoryID=1, ProductModelID=1 },
                new Product{ProductNumber=2, Name="HL Mountain Frame", ListPrice=200.30, Weight=1251.91, CategoryID=2, ProductModelID=2 },
                new Product{ProductNumber=3, Name="HL Mountain Frame", ListPrice=200.30, Weight=1251.91, CategoryID=3, ProductModelID=3 },
           };

            var categories = new Category[]
            {
                new Category{CategoryID=1, Name="Mountain Frames"},
                new Category{CategoryID=2, Name="Road Frames"},
                new Category{CategoryID=3, Name="Mountain Bikes"}
            };
            var models = new ProductModel[]
            {
                new ProductModel{ProductModelID=1, Name="HL Mountain Frame"},
                new ProductModel{ProductModelID=2, Name="LL Road Frame"},
                new ProductModel{ProductModelID=3, Name="ML Mountain Frame-W"},
                new ProductModel{ProductModelID=4, Name="Mountain-100"},
                
            };

            //---------------------------Use Join Query -------------------------

            var result = from p in products
                         join c in categories
                         on p.ProductNumber equals c.CategoryID
                         join m in models
                         on p.CategoryID equals m.ProductModelID
                         select new {p.ProductNumber, Category = c.Name, Model = m.Name, p.Name, p.Cost, p.ListPrice,p.Weight };
            foreach (var item in result)
            {

                Console.WriteLine("\nProduct Name:\t" + $"{item.ProductNumber}");
                Console.WriteLine("\nProduct Name:\t" + $"{item.Name}");
                Console.WriteLine("Product Cost:\t" + $"{item.Cost}");
                Console.WriteLine("Product Price:\t" + $"{item.ListPrice}");
                Console.WriteLine("Product Weight:\t" + $"{item.Weight}");
                Console.WriteLine("\n===================================\n");
            }
            Console.ReadKey();
        }
    }
}

