﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductLINQ
{
    class Product
    {
        //public string Names { get; set; }
        public int ProductNumber { get; set; }
        public string Name { get; set; }
        public double Cost { get; set; }
        public double ListPrice { get; set; }
        public double Weight { get; set; }
        public int CategoryID { get; set; }
        public int ProductModelID { get; set; }
    }
}
