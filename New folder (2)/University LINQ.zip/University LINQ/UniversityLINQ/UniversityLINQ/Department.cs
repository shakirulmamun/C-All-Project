﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniversityLINQ
{
    class Department
    {
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }
        public int StudentID { get; set; }
        public int TeacherID { get; set; }
        public int SubjectID { get; set; }
        public int SeasonID { get; set; }
    }

   

}
