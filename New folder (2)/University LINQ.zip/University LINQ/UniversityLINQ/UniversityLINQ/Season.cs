﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniversityLINQ
{
    class Season
    {
        public int SeasonID { get; set; }
        public string SeasonName { get; set; }
    }
}
